# 复赛测试系统

## 你需要安装的东西

```python```

## 如何使用？

```shell
pip install -r requirements.txt
python app.py
```

注意：如果想在本地使用，而不需要transformers联网，可以下载Model(TinyStories-33M <https://huggingface.co/roneneldan/TinyStories-33M/tree/main>)然后改模型地址即可

## 版权

代码：GPL-3

AI模型：其自己的开源协议