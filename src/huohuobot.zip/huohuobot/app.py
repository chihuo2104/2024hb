from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

from flask import Flask, request

app = Flask(__name__)

@app.route('/')
def get ():
    # Path to your ChromeDriver executable
    chrome_driver_path = '/usr/bin/chromedriver'
    a = time.time()
    # Configure Chrome options
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')  # Run Chrome in headless mode (without opening browser window)
    # chrome_options.add_argument('--disable-gpu')  # Disable GPU acceleration
    # Initialize ChromeDriver with the configured options
    service = Service(chrome_driver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    # URL of the website you want to scrape
    url = request.args.get('url')
    # Open the website
    driver.get(url)
    time.sleep(5)
    decline_button = driver.find_element(By.ID, 'decline')
    decline_button.click()
    # Get the entire body text content
    b = time.time()
    print(b - a)
    # Close the WebDriver session
    driver.quit()
    return "ok"

if __name__ == '__main__':
    app.run(port=11451)
