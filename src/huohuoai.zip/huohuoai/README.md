# huohuoai AI Backend for chi's redbag adventure v.e.r. 2024.

# models需要内置的模型：
TinyStories-33M <https://huggingface.co/roneneldan/TinyStories-33M/tree/main>