[TinyStories 1M]

Good 30

Great 30

Awesome 20

chihuo2104 10

nekovanilla 5

🐢 5